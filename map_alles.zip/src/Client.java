import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.net.*;


public class Client {


    private String HTTPCommand;
    private String port;
    private String language;
    private String URI;
    private String host;
    private String path;
    public Socket socket;

    private static List<String> HTTPCommands = new ArrayList<String>(Arrays.asList("GET", "POST", "PUT", "HEAD"));


    public void Client() {

    }

    /**
     * Returns input arguments splitted after spaces.
     *
     * @return
     */
    public String[] readArguments() {
        Scanner input = new Scanner(System.in);
        String command = input.nextLine();
        return command.split(" ");
    }

    public void setArguments() throws IOException {
        String[] arguments = readArguments();
        if (this.areValidArguments(arguments)) {
            this.HTTPCommand = arguments[0];
            this.port = arguments[2];
            this.language = arguments[3];

            URL url = new URL(arguments[1]);
            this.host = url.getHost();
            this.path = url.getPath();
        }
    }

    /**
     * Checks if arguments are valid arguments.
     * @param arguments
     *        Arguments to be checked.
     * @return
     */
    public boolean areValidArguments(String[] arguments) {
        if (arguments.length != 4) {
            System.out.println("Please, give 4 arguments.");
            return false;
        }

        String HTTPCommand = arguments[0];

        if (!(HTTPCommands.contains(HTTPCommand))) {
            System.out.println("HTTP Command is not valid");
            return false;
        }

        String port = arguments[2];
        if (port != "80") {
            System.out.println("Wrong port number");
            return false;
        }

        return true;
    }

    public static boolean isValidURL(String urlString)
    {
        try
        {
            URL url = new URL(urlString);
            url.toURI();
            return true;
        } catch (Exception exception)
        {
            return false;
        }
    }

    public void connectSocket() throws IOException {
        this.socket = new Socket(this.host, Integer.parseInt(this.port));
    }


    public void sendHEADrequest() {
        String lineOne = this.HTTPCommand + " " + this.host +
    }


    public void sendGETrequest() {
        PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
        output.println("GET " + this.path + "HTTP/1.1");
        output.println("Host: " + this.host + ":" + this.port);
    }


    public void sendPUTPOSTrequest(){

    }

    public void sendCommand() {
        if (a) {

        }
    }
}

